const express = require("express");
const router = express.Router();
const db = require("../db");
const generateCode = require("../utils/shortcode");

router.post("/", (req, res) => {
  const { url, validity = 30, shortcode } = req.body;
  if (!url || typeof url !== "string") {
    return res.status(400).json({ error: "Invalid URL" });
  }

  let code = shortcode || generateCode();
  const exists = db.prepare("SELECT * FROM urls WHERE shortcode = ?").get(code);
  if (exists) {
    return res.status(409).json({ error: "Shortcode already exists" });
  }

  const createdAt = new Date().toISOString();
  const expiry = new Date(Date.now() + validity * 60000).toISOString();
  db.prepare(
    "INSERT INTO urls (shortcode, original_url, created_at, expiry) VALUES (?, ?, ?, ?)"
  ).run(code, url, createdAt, expiry);

  res.status(201).json({ shortLink: `http://localhost:8000/${code}`, expiry });
});

router.get("/:code", (req, res) => {
  const code = req.params.code;
  const record = db.prepare("SELECT * FROM urls WHERE shortcode = ?").get(code);
  if (!record) {
    return res.status(404).json({ error: "Shortcode not found" });
  }
  if (new Date(record.expiry) < new Date())
    return res.status(410).json({ error: "Shortcode expired" });

  db.prepare(
    "INSERT INTO clicks (shortcode, timestamp, referrer, location) VALUES (?, ?, ?, ?)"
  ).run(
    code,
    new Date().toISOString(),
    req.socket.remoteAddress || "Direct",
    "Unknown"
  );

  res.redirect(record.original_url);
});

router.get("/stats/:code", (req, res) => {
  try {
    const code = req.params.code;
    const urlData = db
      .prepare("SELECT * FROM urls WHERE shortcode = ?")
      .get(code);
    if (!urlData) return res.status(404).json({ error: "Shortcode not found" });

    const clicks = db
      .prepare("SELECT * FROM clicks WHERE shortcode = ?")
      .all(code);

    res.json({
      shortcode: code,
      originalUrl: urlData.original_url,
      createdAt: urlData.created_at,
      expiry: urlData.expiry,
      clickCount: clicks.length,
      clicks,
    });
  } catch (err) {
    console.log(err + "Error in stats/code API");
    return res.status(500).json({ status: 400, message: "Failure", data: err });
  }
});

module.exports = router;
